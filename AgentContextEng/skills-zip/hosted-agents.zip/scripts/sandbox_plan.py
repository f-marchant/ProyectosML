#!/usr/bin/env python3
"""hosted-agents: dimensionamiento y planificacion de infraestructura de agentes hospedados (calculos reales, sin red).

Uso:
  python sandbox_plan.py pool-size --arrivals-per-min 6 --warm-minutes 2 [--target 0.99] [--max-pool 500]
  python sandbox_plan.py latency --budget-s 5 --parts "clone=2.5,deps=3,model_ttft=0.8,boot=1.2"
  python sandbox_plan.py image-schedule --commits-per-day 40 --build-minutes 12 --max-staleness-min 30
  python sandbox_plan.py cost --sessions-per-day 200 --session-minutes 25 --price-per-hour 0.35 --idle-pool 4
  python sandbox_plan.py dockerfile CONFIG.json    # {"base":"python:3.12-slim","apt":[...],"pip":[...],"repos":[{"url","path"}],"setup":[...],"workdir":"/work"}
pool-size usa demanda Poisson (lambda = llegadas/min * minutos de calentamiento) y el cuantil objetivo.
"""
import argparse, json, math, sys

def poisson_quantile(lam, q, cap):
    p = math.exp(-lam); c = p; k = 0
    while c < q and k < cap: k += 1; p *= lam / k; c += p
    return k

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a_ = sub.add_parser("pool-size"); a_.add_argument("--arrivals-per-min", type=float, required=True); a_.add_argument("--warm-minutes", type=float, required=True); a_.add_argument("--target", type=float, default=0.99); a_.add_argument("--max-pool", type=int, default=500)
    l_ = sub.add_parser("latency"); l_.add_argument("--budget-s", type=float, required=True); l_.add_argument("--parts", required=True)
    i_ = sub.add_parser("image-schedule"); i_.add_argument("--commits-per-day", type=float, required=True); i_.add_argument("--build-minutes", type=float, required=True); i_.add_argument("--max-staleness-min", type=float, required=True)
    c_ = sub.add_parser("cost"); c_.add_argument("--sessions-per-day", type=float, required=True); c_.add_argument("--session-minutes", type=float, required=True); c_.add_argument("--price-per-hour", type=float, required=True); c_.add_argument("--idle-pool", type=int, default=0)
    d_ = sub.add_parser("dockerfile"); d_.add_argument("file")
    a = ap.parse_args(argv)
    if a.cmd == "pool-size":
        lam = a.arrivals_per_min * a.warm_minutes; n = poisson_quantile(lam, a.target, a.max_pool)
        out = {"expected_concurrent_warmups": round(lam, 2), "pool_size": n, "target_hit_probability": a.target, "note": "Si la tasa varia por hora, calcular con el pico."}
    elif a.cmd == "latency":
        parts = {k: float(v) for k, v in (x.split("=") for x in a.parts.split(","))}; tot = sum(parts.values())
        out = {"total_s": round(tot, 2), "budget_s": a.budget_s, "within_budget": tot <= a.budget_s, "over_by_s": round(max(0, tot - a.budget_s), 2),
               "largest_first": sorted(({"step": k, "s": v, "share_pct": round(100 * v / tot, 1)} for k, v in parts.items()), key=lambda x: -x["s"]),
               "advice": "Mover pasos de preparacion (clone, deps, boot) a la imagen precalentada; dejar solo el TTFT del modelo en la ruta del usuario." if tot > a.budget_s else "Dentro de presupuesto."}
    elif a.cmd == "image-schedule":
        interval = min(a.max_staleness_min - a.build_minutes, a.max_staleness_min)
        feasible = interval > 0; builds = round(1440 / max(interval, 1)) if feasible else None
        out = {"feasible": feasible, "rebuild_every_min": max(1, round(interval)) if feasible else None, "builds_per_day": builds, "build_hours_per_day": round(builds * a.build_minutes / 60, 1) if builds else None,
               "cron": f"*/{max(1, round(interval))} * * * *" if feasible and interval < 60 else None, "commits_between_builds_avg": round(a.commits_per_day / 1440 * max(interval, 0), 1),
               "warning": None if feasible else "El tiempo de build supera la obsolescencia maxima: acelerar el build o relajar el limite."}
    elif a.cmd == "cost":
        run = a.sessions_per_day * a.session_minutes / 60 * a.price_per_hour; idle = a.idle_pool * 24 * a.price_per_hour
        out = {"session_cost_day": round(run, 2), "idle_pool_cost_day": round(idle, 2), "total_day": round(run + idle, 2), "total_month_30d": round(30 * (run + idle), 2), "idle_share_pct": round(100 * idle / (run + idle), 1) if run + idle else 0}
    else:
        c = json.load(open(a.file)); L = [f"FROM {c.get('base', 'ubuntu:24.04')}", "ENV DEBIAN_FRONTEND=noninteractive"]
        if c.get("apt"): L.append("RUN apt-get update && apt-get install -y --no-install-recommends " + " ".join(c["apt"]) + " git ca-certificates && rm -rf /var/lib/apt/lists/*")
        L.append(f"WORKDIR {c.get('workdir', '/work')}")
        for r in c.get("repos", []): L.append(f"RUN git clone --depth 1 {r['url']} {r.get('path', '.')}")
        if c.get("pip"): L.append("RUN pip install --no-cache-dir " + " ".join(c["pip"]))
        for s in c.get("setup", []): L.append(f"RUN {s}")
        L.append('CMD ["sleep", "infinity"]'); print("\n".join(L)); return 0
    print(json.dumps(out, ensure_ascii=False, indent=2)); return 0

if __name__ == "__main__": sys.exit(main())
